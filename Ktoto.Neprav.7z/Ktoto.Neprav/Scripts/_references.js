﻿/// <reference path="modernizr-2.7.2.js" />
/// <reference path="jquery-ui-1.10.4.js" />
/// <reference path="jquery-2.1.1.js" />
/// <reference path="jquery.validate.js" />
/// <reference path="jquery.validate.unobtrusive.js" />
/// <reference path="knockout-2.2.0.debug.js" />
