﻿namespace Ktoto.Neprav.Models
{
	public class IdentityInfo
	{
		public Author Author { get; set; } 
	}
}